/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exoformeminimal;

/**
 *
 * @author droch
 */
public class ExoFormeMinimal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IhmSwing myIhm = new IhmSwing();
        Dessin dessin1 = myIhm.getDessin();
        Forme arcE = new ArcEllipse(new Point(50,50), 100,80,0,180);
	dessin1.addForme(arcE);
        
        Forme E1 = new Rectangle(new Point(100,100), 100,80);
        dessin1.addForme(E1);
        
        myIhm.setVisible(true);

    }
    
}
