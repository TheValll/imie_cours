<!DOCTYPE html>
<html>
    <head>
		<title>Forms</title>
	</head>
	<body>
        <p>Fen&ecirc;tre de login</p>
		<form action="./AcceptLogin.php" method="post">
            <label>Nom: <input type="text" name="id" size="30" maxlength="100"></label><br />
            <label>Pswd: <input type="password" name="pswd" size="30" maxlength="100"></label><br />
            <input type="submit" value="Identifier" />
        </form>
    </body>
</html>