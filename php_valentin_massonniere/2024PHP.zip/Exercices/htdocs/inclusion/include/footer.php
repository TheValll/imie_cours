    <footer id="pied_de_page">
        <p>Pied de page</p>
        <p>Copyright moi, tous droits réservés</p>
    </footer>
