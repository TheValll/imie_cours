<!DOCTYPE html>
<html  >
<head>
     <meta charset="utf-8" />
     <title>Réception </title>
</head>
<body>
    <p>réception d'un message en GET</p>
    <?php
	// du code PHP ici pour afficher le nom et prénom reçus en GET
	// Afficher aussi le type de méthode Get ou Post
    
    ?>
    <!-- <script  type="text/javascript">alert('Vous avez 5 minutes pour payer la rançon')</script> -->

</body>
</html>