<?php
class Logger {
    const INFO = 'Info';
    const WARNING = 'Warning';
    const ERROR = 'Error';
    private static $logFile = __DIR__ . '/../app.log';

    public static function log($level, $message, $user = '-', $result = '-', $ip = null) {
        $date = date('Y/m/d H:i:s');
        $ip = $ip ?? ($_SERVER['REMOTE_ADDR'] ?? '-');
        $logMsg = "$date $level : user=$user ip=$ip result=$result $message\n";
        error_log($logMsg, 3, self::$logFile);
    }
}
?>