<?php
class Database { 
    private static $dbName = 'personfilm'; 
    private static $dbHost = 'localhost'; 
    private static $cont = null; 

    public function __construct() { 
        die('Init function is not allowed'); 
    } 

    public static function connect(int $niveau) { 
        if ($niveau === 3) { // admin
            $dbUsername = 'PFAdmin';
            $dbUserPassword = 'admin';
        } elseif ($niveau === 2) { // utilisateur connecté
            $dbUsername = 'PFConnecte';
            $dbUserPassword = 'cc';
        } else { // invité/non connecté
            $dbUsername = 'PFNonConnecte';
            $dbUserPassword = 'nc';
        }

        if (null == self::$cont) { 
            try { 
                self::$cont = new PDO(
                    "mysql:host=".self::$dbHost.";dbname=".self::$dbName,
                    $dbUsername,
                    $dbUserPassword
                ); 
            } catch(PDOException $e) { 
                die($e->getMessage()); 
            }
        }
        return self::$cont;
    }

    public static function disconnect() {
        self::$cont = null;
    }
}
?>