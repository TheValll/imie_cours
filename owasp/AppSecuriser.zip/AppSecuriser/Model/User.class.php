<?php
include_once('connectionSql.php');

if (!isset($_SESSION)) session_start();

class User {
    private $idUser;
    private $username;
    private $email;
    private $password;
    private $level;
    public function __construct(int $pIdUser, string $pUsername, string $pEmail, string $pPassword, ?int $pLevel = null)
    {
        $this->idUser = $pIdUser;
        $this->username = $pUsername;
        $this->email = $pEmail;
        $this->password = $pPassword;
        $this->level = $pLevel;
    }

    public function getIdUser() { return $this->idUser; }
    public function getUsername() { return $this->username; }
    public function getEmail() { return $this->email; }
    public function getPassword() { return $this->password; }
    public function getLevel() { return $this->level; }
}

class ManageUsers {
    public function addUser(string $pUsername, string $pEmail, string $pPassword, int $pLevel = 1) {
        if (gettype($pUsername) != 'string' || gettype($pEmail) != 'string' || gettype($pPassword) != 'string')
            return null;

        $pdo = Database::connect($_SESSION['level'] ?? 0);

        $req = $pdo->prepare("SELECT * FROM users WHERE username=? AND email=?");
        $req->execute(array($pUsername, $pEmail));
        if ($req->fetch()) {
            echo "Utilisateur déjà existant $pUsername";
            return null;
        }

        $hashPswd = password_hash($pPassword, PASSWORD_BCRYPT);

        $req = $pdo->prepare("INSERT INTO users (id, username, email, password, level) VALUES (NULL, ?, ?, ?, ?)");
        if ($req->execute(array($pUsername, $pEmail, $hashPswd, $pLevel))) {
            echo "Utilisateur ajouté $pUsername";
            $lastId = $pdo->lastInsertId();
            $user = new User($lastId, $pUsername, $pEmail, $hashPswd, $pLevel);
            return $user;
        }

        return null;
    }

    public function verifyUser(string $pUsername, string $pEmail, string $pPassword) {
        $pdo = Database::connect($_SESSION['level'] ?? 0);

        $req = $pdo->prepare("SELECT * FROM users WHERE username=? AND email=?");
        if ($req->execute(array($pUsername, $pEmail))) {
            $userData = $req->fetch();
            if ($userData && password_verify($pPassword, $userData['password'])) {
                $user = new User(
                    $userData["id"], 
                    $userData["username"], 
                    $userData["email"], 
                    $userData["password"], 
                    $userData["level"] ?? null
                );
                return $user;
            } else {
                echo "Mot de passe incorrect ou utilisateur non trouvé";
            }
        }

        return null;
    }
}
