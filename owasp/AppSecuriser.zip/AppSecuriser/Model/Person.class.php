<?php
include_once('connectionSql.php'); //on inclut notre fichier de connection 

if (!isset($_SESSION)) session_start();
 
class Person {

    private $idPerson;
    private $name;
    private $firstName;
    private $filmIdList=array(); // id des films associés à la Person

    public function __construct(int $pid, string $pname, string $pfirstName){
        $this->idPerson = $pid;
        $this->name = $pname;
        $this->firstName = $pfirstName;
    }

    public function getIdPerson(){
        return $this->idPerson;
    }
    public function getName(){
        return $this->name;
    }
    public function getFisrtName(){
        return $this->firstName;
    }
    public function getFilmIdList(){
        return $this->filmIdList;
    }

    public function addFilm(int $pIdFilm){
        // ajoute un objet Film à filmList
        $this->filmIdList[] = $pIdFilm;
    }
}

class ManagePersons {
    private $personList=array();
    private $manageFilms;   // pour réaliser l'association Person vers Film

    public function setManageFilms($pManageFilms){
        $this->manageFilms = $pManageFilms;
    }

    public function getPersonsFromDB()
    {
        $pdo = Database::connect($_SESSION['level'] ?? 0); 
        $sql = 'SELECT * FROM person ORDER BY idPerson ASC'; //on formule notre requete 
        $result = $pdo->query($sql);
        $allRows = $result->fetchAll();

        foreach ($allRows as $row) { //on cree un objet Person avec chaque valeur retournée
            $name = $row["name"];
            $firstName = $row["firstName"];
            $id = $row["idPerson"];
            $person = new Person($id,$name,$firstName);
            $this->personList[] = $person;
            // il faut renseigner les id de films éventuels de la personne
            $sqlFilm = "SELECT idFilm FROM regarder where idPerson = $id"; 
            $resultFilm = $pdo->query($sqlFilm);
            $allRowsFilm = $resultFilm->fetchAll();
            foreach ($allRowsFilm as $rowFilm){
                $idFilm = $rowFilm["idFilm"];
                $person->addFilm($idFilm);
            }
        }
        $result->closeCursor();
        
        return $this->personList;

    }
    public function getPersons(){
        if ( count($this->personList) == 0)
            $this->getPersonsFromDB();
        return $this->personList;
    }
    public function getPersonFromId(int $id){
        // retourne l'objet Person connaissant son id
        // retourne null si pas trouvée
        foreach ($this->personList as $person) {
            if ($person->getIdPerson() == $id)
                return $person;
        }
        return null;
    }
    public function getPersonOffsetFromId(int $id){
        // retourne le rang dans personList de l'objet Person connaissant son id
        // retourne -1 si pas trouvée
        $offset = 0;
        foreach ($this->personList as $person) {
            if ($person->getIdPerson() == $id)
                return $offset;
            $offset ++;
        }
        return -1;
    }

    public function addPerson(string $pname, string $pfirstName, $type = 'Mineur') {
        if (!is_string($pname) || !is_string($pfirstName) || !is_string($type)) {
            return null;
        }

        $pdo = Database::connect($_SESSION['level'] ?? 0);

        $sql = "INSERT INTO person (name, firstName, type) VALUES (:name, :firstName, :type)";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([
            ':name' => $pname,
            ':firstName' => $pfirstName,
            ':type' => $type
        ]);

        if ($success) {
            echo "Personne ajoutée " . htmlspecialchars($pname);
            $lastId = $pdo->lastInsertId();
            $person = new Person($lastId, $pname, $pfirstName);
            $this->personList[] = $person;
            return $person;
        } else {
            return null;
        }
    }

    public function addFilmToPerson(int $pIdPerson, int $pIdFilm){
        // Pour la Person correspondant à $pIdPerson, ajouter le film en BD et dans l'objet Person
        $pdo = Database::connect($_SESSION['level'] ?? 0);
        // Vérifier d'abord que ce film n'est pas déjà affecté à la personne
        $sql = "SELECT * FROM regarder WHERE idFilm=$pIdFilm AND idPerson=$pIdPerson"; //on formule notre requete 
        $result = $pdo->query($sql);
        $allRows = $result->fetchAll();
        if (sizeof($allRows) != 0)
            return; // déjà affecté

        $sql = "INSERT INTO regarder (idPerson, idFilm) VALUES ($pIdPerson, $pIdFilm)";
        $result = $pdo->query($sql);
        if ($result == true) {
            echo "Film ajouté"; // le temps du debug
            $person = $this->getPersonFromId($pIdPerson);
            $person->addFilm($pIdFilm);
        }
    }

    public function deletePerson(int $pIdPerson){
        // supprimer une personne connaissant son id
        // retourne true si ok
        $pdo = Database::connect($_SESSION['level'] ?? 0);
        // avant de supprimer la personne en BD, il faut d'abord supprimer les liens vers les films
        // dans la table regarder, sinon le serveur BD refuse
        $req = $pdo->prepare("DELETE FROM regarder WHERE regarder.idPerson = ?;"); // supprimer le lien en BD
        if ($req->execute(array($pIdPerson)) == true) {
            $req = $pdo->prepare("DELETE FROM person WHERE person.idPerson = ?;"); // supprimer cette fois la Person en BD
            if ($req->execute(array($pIdPerson)) == true) {
                // supprimer maintenant l'objet
                $offset = $this->getPersonOffsetFromId($pIdPerson);
                if ($offset == -1)
                    return false;
                unset($this->personList[$offset]);
                // echo "<br>Delete<br>";
                // print_r($this->personList); // debug
                // echo "<br>";
                // supprimer l'idPerson coté Film
                $this->manageFilms->deletePersonInFilms($pIdPerson);
                return true;
            }
        }
        return false;
    }
    public function modifyPerson(int $pid, int $pname, int $pfirstName) {
        // modifie les données en Bd et dans l'objet 
        // A implémenter
    }

}
/*
$manager = new ManagePersons();
$manager->getPersonsFromDB();
$manager->addPerson("AAZZEE","qqssdd");
$manager->deletePerson(6);
*/
?>