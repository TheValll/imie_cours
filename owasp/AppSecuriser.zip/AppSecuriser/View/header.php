<?php
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 600)) {
    session_unset();    
    session_destroy(); 
}
$_SESSION['LAST_ACTIVITY'] = time();

if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<html lang="fr">
    <head>
        <title><?php echo isset($titre) ? $titre : 'Titre'; ?> </title>
        <meta charset="utf-8">
        <meta name="description" content="Un site avec Bootstrap"/>
        <meta name="keywords" content ="site, bootstrap"/>
        <meta name="author" content="Antoine Baudry"/>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://bootswatch.com/5/flatly/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarColor02">
              <ul class="navbar-nav me-auto">
                <li class="nav-item">
                  <a class="nav-link active" href="index.php">Home
                    <span class="visually-hidden">(current)</span>
                  </a>
                </li>
                <?php if (!isset($_SESSION['username'])): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="index.php?page=5">S'inscrire</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="index.php?page=6">Se connecter</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                      <a class="nav-link" href="index.php?page=1">Personnes</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="index.php?page=2">Films</a>
                    </li>
                    <?php if (isset($_SESSION['level']) && $_SESSION['level'] == 2): ?>
                        <!-- Liens supplémentaires pour l'administrateur -->
                        <li class="nav-item">
                          <a class="nav-link" href="index.php?page=admin">Admin Panel</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                      <a class="nav-link" href="index.php?page=8">Deconnecter</a>
                    </li>
                <?php endif; ?>
              </ul>
              <form class="d-flex">
                <input class="form-control me-sm-2" type="text" placeholder="Search">
                <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
              </form>
              <span class="navbar-text text-white ms-3">
                <?php if (isset($_SESSION['username'])): ?>
                    Connecté en tant que <b><?= htmlspecialchars($_SESSION['username']) ?></b>
                <?php endif; ?>
              </span>
            </div>
          </div>
        </nav>