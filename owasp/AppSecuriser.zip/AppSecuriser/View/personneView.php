<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nom</th>
      <th scope="col">Prénom</th>
    </tr>
  </thead>
  <tbody>
    <?php
    if (!isset($_SESSION)) session_start();
    foreach ($personList as $person) {
      $id = $person->getIdPerson();
      $name = $person->getName();
      $firstName = $person->getFisrtName();
      echo "<tr class=\"table-active\">
      <td>$id</td>
      <td>$name</td>
      <td>$firstName</td>
      <td><a href=\"index.php?page=3&index=$id\" class=\"btn btn-primary\">Vue de détail</a> </td>";
      // Afficher le bouton supprimer seulement pour l'admin
      if (isset($_SESSION['level']) && $_SESSION['level'] == 3) {
        $token = isset($_SESSION['token']) ? $_SESSION['token'] : '';
        echo "<td><a href=\"index.php?page=7&index=$id&token=$token\" class=\"btn btn-danger\">Supprimer</a> </td>";
      }
      echo "</tr>";
    }
    ?>
    
  </tbody>
</table>
<img class="img-fluid" src="./view/blank.png" height="300">
