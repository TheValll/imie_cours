<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Consentement RGPD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Protection des données personnelles</h2>
    <p>
        Ce site sauvegarde des données personnelles (nom, prénom, email) dans sa base de données.<br><br>
        En poursuivant, vous acceptez cette sauvegarde conformément au RGPD.
    </p>
    <form method="post">
        <button type="submit" name="accepter" class="btn btn-success">J'accepte</button>
        <a href="index.php" class="btn btn-secondary">Refuser</a>
    </form>
</div>
</body>
</html>