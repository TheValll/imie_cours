<?php
    include_once('./model/connectionSql.php');
    include_once('./model/Film.class.php');
    include_once('./model/Person.class.php');
    $managerFilm = new ManageFilms();
    $allFilmList = $managerFilm->getFilmsFromDB();

    $managerPerson = new ManagePersons();
    $managerPerson->setManageFilms($managerFilm); 
    $managerPerson->getPersonsFromDB();
    
    if(isset($_GET['index'])) {	
        $index = $_GET['index'];
        $person = $managerPerson ->getPersonFromId($index);
        if ($person != null){
            $filmList = array();
            $filmIdList = $person->getFilmIdList();
            foreach ($filmIdList as $idFilm){
                $film = $managerFilm->getFilmFromId($idFilm);
                $filmList[] = $film;
            }
            include("view/detailPersonneView.php"); 
        }
    }
    if (isset($_POST['name'])){
        echo "retour de formulaire";
        if (isset($_POST['films'])){
            $idFilm = $_POST['films'];
            $idPerson = $person->getIdPerson();
            $managerPerson->addFilmToPerson($idPerson, $idFilm);
            //header("Location: index.php?page=3&index=$idPerson"); 
            echo "<meta http-equiv=\"refresh\" content=\"0\"; url=\"index.php?page=3&index=$idPerson\">";
        }
    }
?>