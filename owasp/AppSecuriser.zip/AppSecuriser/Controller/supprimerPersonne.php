<?php
if (
    !isset($_SESSION['token']) ||
    !isset($_GET['token']) ||
    $_SESSION['token'] !== $_GET['token']
) {
    die("Accès refusé (CSRF token invalide)");
}

include_once('./model/connectionSql.php');
include_once('./model/Film.class.php');
include_once('./model/Person.class.php');
$managerFilm = new ManageFilms();
$filmList = $managerFilm->getFilmsFromDB();

$managerPerson = new ManagePersons();
$managerPerson->setManageFilms($managerFilm); // pour réaliser l'association de Person vers Film
$managerPerson->getPersonsFromDB();

if(isset($_GET['index'])) { 
    $index = $_GET['index'];
    $person = $managerPerson->getPersonFromId($index);
    if ($person != null){
        $managerPerson->deletePerson($index); // enlève de la BD et de la liste
        header("Location: index.php?page=1");
        exit();
    }
}
?>